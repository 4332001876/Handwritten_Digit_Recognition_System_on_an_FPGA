import numpy as np
import struct
import time

def float_to_hex(f):
    return hex(struct.unpack('<I', struct.pack('<f', f))[0])
def to_binary(num,width=5):
    s=''
    for i in range(width):
        s=('%d'%(num%2))+s
        num=num//2
    return ('%d\'b'%width)+s

for i in range(17):
    print(to_binary(i)+": begin\n\twdata<=32\'h"+float_to_hex((i/16.0-0.1307)/0.3081)[2:]+";\nend")













time.sleep(5000)
