import numpy as np
import struct
import time

def float_to_hex(f):
    return hex(struct.unpack('<I', struct.pack('<f', f))[0])
def to_binary(num,width=4):
    s=''
    for i in range(width):
        s=('%d'%(num%2))+s
        num=num//2
    return ('%d\'b'%width)+s

print("case(q)")
for i in range(9):
    print(to_binary(i)+": begin\n\t"+"raddr=temp_raddr[NN_ADDR_WIDTH*%d-1:NN_ADDR_WIDTH*%d];\n"%(i+1,i)+
    "\twaddr=temp_waddr[NN_ADDR_WIDTH*%d-1:NN_ADDR_WIDTH*%d];\n"%(i+1,i)+
    "\twdata=temp_wdata[32*%d-1:32*%d];\n"%(i+1,i)+
    "\twe=temp_we[%d];\n"%(i)+
    "end")