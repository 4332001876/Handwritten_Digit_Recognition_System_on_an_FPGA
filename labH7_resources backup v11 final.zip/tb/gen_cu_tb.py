import numpy as np
import struct
import time

def float_to_hex(f):
    return hex(struct.unpack('<I', struct.pack('<f', f))[0])
def hex_to_float(h):
    return struct.unpack('<f', struct.pack('<I', h))[0]

rf=[0 for i in range(128)]
#a=np.array([np.random.randint(0,2) for _ in range(64)]).reshape(8,8).tolist()
#print(a)
a=[[1, 1, 0, 0, 0, 1, 1, 0], [0, 0, 1, 0, 1, 1, 1, 1], [1, 1, 0, 1, 0, 1, 1, 0], [1, 0, 0, 0, 1, 1, 0, 0],
 [0, 1, 0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 1, 0, 0], [1, 1, 1, 1, 0, 0, 1, 0], [1, 0, 1, 0, 1, 0, 1, 0]]
for i in range(2):
    for j in range(2):
        counter=0
        for m in range(4):
            for n in range(4):
                if(a[i*4+m][j*4+n]==1):
                    counter+=1
                    rf[(i*4+m)*8+j*4+n]='32\'h'+'fff'
                else:
                    rf[(i*4+m)*8+j*4+n]='32\'h'+'000'
                
        rf[64+i*2+j]='32\'h'+float_to_hex((counter/16.0-0.1307)/0.3081)[2:]

#[  47.669434 2973.7961  ]
'''for i in range(3):
    if(c[i]<0):
        c[i]=0'''
for i in range(68):
    print(('rf[%d]='%(i))+rf[i]+';')




#print(hex_to_float(0x41234424))
#print(float_to_hex(5.3455*1.23))
time.sleep(5000)


'''
rf[0]=32'h3f9d70a4;
rf[1]=32'h408b4e3c;
rf[2]=32'h405c7ae1;
rf[3]=32'h435f49cd;
rf[4]=32'h422cef9e;
rf[5]=32'h43b1ac08;
rf[6]=32'h40160419;
rf[7]=32'h40ab0e56;
rf[8]=32'h40c7db23;
rf[9]=32'h423ead80;
rf[10]=32'h4539dcbd;
'''