import numpy as np
import struct
import time

def float_to_hex(f):
    return hex(struct.unpack('<I', struct.pack('<f', f))[0])
def hex_to_float(h):
    return struct.unpack('<f', struct.pack('<I', h))[0]
rf=[0 for i in range(100)]
#a=np.random.random(size=(2,2,2))
#print(a)
a=[[[0.16169365, 0.11727228, 0.34021119, 1.34455], 
  [0.96094503, 0.26615705, 0.23023314,-1.4566], 
  [0.81112079, 0.2994549,  0.41570554, 0.87689],
  [0.93675207, 0.09450155, 0.35125103,-2.14]],

 [[0.41836218, 0.30064916, 0.11577295, 1.245],
  [0.81112079, 0.2994549,  0.41570554, 0.87689],
  [0.00965526, 0.53215443, 0.0445062 ,0.1387827],
  [0.93675207, 0.09450155, 0.35125103,-2.14]]]
result=np.zeros((2,2,2),dtype=np.float32)
#a=np.array([[1.23,4.3533,3.445],[223.28828,43.234,355.344]],dtype=np.float32)
for i in range(2):
    for j in range(2):
        
        for c in range(2):
            result=-9999999999999
            for ki in range(2):
                for kj in range(2):
                    if(a[c][i*2+ki][j*2+kj]>result):
                        result=a[c][i*2+ki][j*2+kj]
                    print(('step%d-%dresult:'%(i*2+j,c))+'32\'h'+float_to_hex(result)[2:]+';')
            rf[32+4*c+2*i+j]=result
for i in range(2):
    for j in range(4):
        for k in range(4):
            print(('rf[%d]='%(i*16+j*4+k))+'32\'h'+float_to_hex(a[i][j][k])[2:]+';')

for i in range(32,40):
    print(('rf[%d]='%(i))+'32\'h'+float_to_hex(rf[i])[2:]+';')




#print(hex_to_float(0x41234424))
#print(float_to_hex(5.3455*1.23))
time.sleep(5000)


'''
rf[0]=32'h3f9d70a4;
rf[1]=32'h408b4e3c;
rf[2]=32'h405c7ae1;
rf[3]=32'h435f49cd;
rf[4]=32'h422cef9e;
rf[5]=32'h43b1ac08;
rf[6]=32'h40160419;
rf[7]=32'h40ab0e56;
rf[8]=32'h40c7db23;
rf[9]=32'h423ead80;
rf[10]=32'h4539dcbd;
'''