import numpy as np
import struct
import time

def float_to_hex(f):
    return hex(struct.unpack('<I', struct.pack('<f', f))[0])
def hex_to_float(h):
    return struct.unpack('<f', struct.pack('<I', h))[0]
rf=[0 for i in range(100)]
#a=np.random.random(size=(2,2,2))
#print(a)
a=[[[0.16169365, 0.11727228, 0.34021119], 
  [0.96094503, 0.26615705, 0.23023314], 
  [0.93675207, 0.09450155, 0.35125103]],

 [[0.41836218, 0.30064916, 0.11577295],
  [0.81112079, 0.2994549,  0.41570554],
  [0.00965526, 0.53215443, 0.0445062 ]]]
kernel1=[[[0.46402773, 0.73626231],
  [0.00631405, 0.86684077]],

 [[0.88213503, 0.44676761],
  [0.39846378, 0.90022403]]]
kernel2=[[[0.01422938, 0.41005407],
        [0.33047797, 0.08000082]],

       [[0.31167733, 0.44130447],
        [0.49394342, 0.37948726]]]
kernel=kernel1
#a=np.array([[1.23,4.3533,3.445],[223.28828,43.234,355.344]],dtype=np.float32)
for i in range(2):
    for j in range(2):
        result=0
        for c in range(2):
            for ki in range(2):
                for kj in range(2):
                    mul_result=a[c][i+ki][j+kj]*kernel[c][ki][kj]
                    result+=mul_result
                    print(('step1-%d-%d-mul:'%(i*2+j,c*4+ki*2+kj))+'32\'h'+float_to_hex(mul_result)[2:]+';')
                    print(('step1-%d-%dresult:'%(i*2+j,c*4+ki*2+kj))+'32\'h'+float_to_hex(result)[2:]+';')
        rf[34+2*i+j]=result
kernel=kernel2
#a=np.array([[1.23,4.3533,3.445],[223.28828,43.234,355.344]],dtype=np.float32)
for i in range(2):
    for j in range(2):
        result=0
        for c in range(2):
            for ki in range(2):
                for kj in range(2):
                    mul_result=a[c][i+ki][j+kj]*kernel[c][ki][kj]
                    result+=mul_result
                    print(('step2-%d-%d-mul:'%(i*2+j,c*4+ki*2+kj))+'32\'h'+float_to_hex(mul_result)[2:]+';')
                    print(('step2-%d-%dresult:'%(i*2+j,c*4+ki*2+kj))+'32\'h'+float_to_hex(result)[2:]+';')
        rf[38+2*i+j]=result
for i in range(2):
    for j in range(3):
        for k in range(3):
            print(('rf[%d]='%(i*9+j*3+k))+'32\'h'+float_to_hex(a[i][j][k])[2:]+';')

for i in range(2):
    for j in range(2):
        for k in range(2):
            print(('rf[%d]='%(18+i*4+j*2+k))+'32\'h'+float_to_hex(kernel1[i][j][k])[2:]+';')

for i in range(2):
    for j in range(2):
        for k in range(2):
            print(('rf[%d]='%(26+i*4+j*2+k))+'32\'h'+float_to_hex(kernel2[i][j][k])[2:]+';')



for i in range(34,42):
    print(('rf[%d]='%(i))+'32\'h'+float_to_hex(rf[i])[2:]+';')




#print(hex_to_float(0x41234424))
#print(float_to_hex(5.3455*1.23))
time.sleep(5000)


'''
rf[0]=32'h3f9d70a4;
rf[1]=32'h408b4e3c;
rf[2]=32'h405c7ae1;
rf[3]=32'h435f49cd;
rf[4]=32'h422cef9e;
rf[5]=32'h43b1ac08;
rf[6]=32'h40160419;
rf[7]=32'h40ab0e56;
rf[8]=32'h40c7db23;
rf[9]=32'h423ead80;
rf[10]=32'h4539dcbd;
'''