import numpy as np
import struct
import time

def float_to_hex(f):
    return hex(struct.unpack('<I', struct.pack('<f', f))[0])
def hex_to_float(h):
    return struct.unpack('<f', struct.pack('<I', h))[0]


a=np.array([1.23,4.3533,3.445,2.344,5.3455,6.2455,0.81112079, 0.2994549,  0.41570554,5.0],dtype=np.float32)
c=np.argmax(a)
for i in range(10):
    print(('rf[%d]='%(i))+'32\'h'+float_to_hex(a[i])[2:]+';')

print("argmax:",c)



#print(hex_to_float(0x41234424))
#print(float_to_hex(5.3455*1.23))
time.sleep(5000)


'''
rf[0]=32'h3f9d70a4;
rf[1]=32'h408b4e3c;
rf[2]=32'h405c7ae1;
rf[3]=32'h435f49cd;
rf[4]=32'h422cef9e;
rf[5]=32'h43b1ac08;
rf[6]=32'h40160419;
rf[7]=32'h40ab0e56;
rf[8]=32'h40c7db23;
rf[9]=32'h423ead80;
rf[10]=32'h4539dcbd;
'''