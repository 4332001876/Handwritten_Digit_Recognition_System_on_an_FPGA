## bug
- 位宽
- 在一长段时间的第一周期还是最后一周期，如`assign addr_pe=((pos==MAX-1)&&(cycle_pe))?1:0;`
- always & reg
- [Synth 8-91] ambiguous clock in event control ["D:/Verilog/2022_fall_lab/lab_6/labH6_resources/pu.v":44]

## new
### onboard
- 小心，bias必须准确无误地只加一次




### finished
- nn_busy & nn_st in nn_check




## 工作计划
- 现在应该就两个难点，第一个是改block memory；第二个是把训好的神经网络里的数装在block memory正确的位置上
- bias & pooling & 字库显示 & 拼装


## dst
分辨率
像素
频率
（MHz）



800x600@72Hz 50MHz 
行/场同步极性+/+


行总像素 行同步脉冲宽度 行同步后沿 行显示像素 行同步前沿
场总行数 场同步脉冲宽度 场同步后沿 场显示行数 场同步前沿
1040     120             64          800       56 
666        6             23          600       37

        H   L  L  L

0-119(-1,119)

## ddp
横向0数到199后，addr应回3次，第4（CYCLE）次才改变
用d来输入行数

## tensor_memory_unit分配nn
```python
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 10, kernel_size=5)
        self.conv2 = nn.Conv2d(10, 20, kernel_size=5)
        self.conv2_drop = nn.Dropout2d()
        self.fc1 = nn.Linear(320, 50)
        self.fc2 = nn.Linear(50, 10)

    def forward(self, x):
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2_drop(self.conv2(x)), 2))
        x = x.view(-1, 320)
        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)
        return F.log_softmax(x, dim=1)
```
> torch的view()与reshape()方法都可以用来重塑tensor的shape，区别就是使用的条件不一样。view()方法只适用于满足连续性条件的tensor，并且该操作不会开辟新的内存空间，只是产生了对原存储空间的一个新别称和引用，返回值是视图。而reshape()方法的返回值既可以是视图，也可以是副本，当满足连续性条件时返回view，否则返回副本[ 此时等价于先调用contiguous()方法在使用view() ]。因此当不确能否使用view时，可以使用reshape。如果只是想简单地重塑一个tensor的shape，那么就是用reshape，但是如果需要考虑内存的开销而且要确保重塑后的tensor与之前的tensor共享存储空间，那就使用view()。
### version 1
```txt
源数据：784

分配：10个卷积核，10*(1*5*5)=250
得到10*24*24=5760
pool:10*12*12=1440
7450

20个卷积核，20*(10*5*5)=5000
得到20*8*8=1280
pool:20*4*4=320
6600

(reshape:320)
320*50+50=16050
50*50+10=2510
18560

7450+6600+18560=32610
784+32610=33394

```

```txt
源数据：784   offset:0

分配：10个卷积核，10*(1*5*5)=250    offset:784
得到10*24*24=5760    offset:1034
pooling out:10*12*12=1440    offset:6794
7450

20个卷积核，20*(10*5*5)=5000     offset:8234
得到20*8*8=1280    offset:13234
pooling out:20*4*4=320    offset:14514
6600

(reshape:320)    
320*50+50=16050    
offset:14834
output(50) offset:30834

50*50+10=2510    
offset:30884
output(10) offset:33384
18560

7450+6600+18560=32610  
784+32610=33394

```
### version 2
```txt
源数据：784   offset:0

分配：10个卷积核，10*(1*5*5)=250    offset:784
得到10*24*24=5760    offset:1034
max pooling out:10*12*12=1440    offset:6794
7450

20个卷积核，20*(10*5*5)=5000     offset:8234
得到20*8*8=1280    offset:13234
max pooling out:20*4*4=320    offset:14514
6600

(reshape:320)    
320*50+50+50=16100    
offset:14834
bias(50) offset:30834
output(50) offset:30884

50*10+10+10=520    
offset:30934
bias(10) offset:31434
output(10) offset:31444
16620

7450+6600+16620=30670  
784+30670=31454

```

## tensor_memory_unit分配simple_nn
```txt
源数据：784   offset:0

784*20+20+20+20=15740    
offset:784
bias(20) offset:16464
before_bias output(20) offset:16484
output(20) offset:16504

20*10+10+10+10=230    
offset:16524
bias(10) offset:16724
before_bias output(10) offset:16734
output(10) offset:16744
16754个数据







```

## matmul实现


## conv实现



## matmul与conv2D修改
> 改完检查一下整个模块
### 共通
1. 计数器位宽改为16，大于神经网络参数量33394
2. 简化逻辑
3. 状态机改为4位，注意ns与cs的位数(mul加了两个读数的状态)
4. NS==IDLE时，令`busy = 1'b0;`用于及时掐断st信号

### matmul特殊


### conv2D特殊
1. 遍历完一层特征图之后，channel+=1，遍历下一层特征图
```txt
考虑2*3*3用2*2*2来卷，

```


















